<?php
include_once"./dbHandler.php";

// Entraîner le classificateur avec les données
$con=new dbHandler;
$con->connectDB();
$donneesEntrainement = $con->getInDBWithInner("id,name,category.name","product","category","id","categoryId",null);

// Récupérer les catégories et les IDs des produits pour faire des prédictions
$categories = [];
$productIds = [];
foreach ($donneesEntrainement as $element) {
  $categories[] = $element['category.name'];
  $productIds[] = $element['id'];
}

// Trouver le produit le plus proche dans la catégorie
$testProductId = 6;
$minDistance = PHP_INT_MAX;
$nearestProductId = -1;
$nearestProductCategory = '';

foreach ($donneesEntrainement as $element) {
  $distance = abs($element['id'] - $testProductId);
  if ($distance < $minDistance) {
    $minDistance = $distance;
    $nearestProductId = $element['id'];
    $nearestProductCategory = $element['category.name'];
  }
}

// Recommander des produits similaires en fonction de la catégorie du produit le plus proche
$productIdsRecommandes = [];
foreach ($donneesEntrainement as $element) {
  if ($element['category.name'] === $nearestProductCategory) {
    $productIdsRecommandes[] = $element;
  }
}

// Afficher les produits recommandés à l'utilisateur
echo "Produits recommandés pour productId $testProductId :\n";
print_r($productIdsRecommandes);